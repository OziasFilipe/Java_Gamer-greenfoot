import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class DashSmoke extends Gifs{
    private boolean isFirstImage;
    private GreenfootImage firstImage;
    private GifImage gif = new GifImage("boom5.gif");
    
    public void act(){
        for(GreenfootImage frame : gif.getImages()){
            frame.scale(60,60);
        }
        
        setImage(gif.getCurrentImage());
        
        if(firstImage==null){
            firstImage=getImage();
            isFirstImage=true;
        }
        if(isFirstImage != (getImage() == firstImage)){
            isFirstImage = ! isFirstImage;
            if (isFirstImage) getWorld().removeObject(this);
        }
    }
}
