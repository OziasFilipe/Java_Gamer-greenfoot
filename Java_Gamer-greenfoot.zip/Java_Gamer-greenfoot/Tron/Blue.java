import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Blue extends Moto{
    private int limiteCount = 0;
    private int limite = 3;
    
    public Blue(){
        setCor();
        this.limiteCount = this.limite;
    }
    
    public void act(){
        if(!getFim()){
            move(getVelocidade());
        }
        virar();
        rastro();
        if(!getFim()){
            tocar();
        }
        boost();
    }
    
    public void virar(){
        if(Greenfoot.isKeyDown("a")){
            turn(-2);
        }
        if(Greenfoot.isKeyDown("d")){
            turn(2);
        }
        if(Greenfoot.isKeyDown("space")){
            flash();
        }
    }
    
    public void rastro(){
        if(getBlocked()==0){
            this.limiteCount--;
            if(this.limiteCount==0){
                this.limiteCount = this.limite;
                
                double radiano = Math.toRadians(this.getRotation());
                int pX = (int)(48*(Math.cos(radiano)));
                int pY = (int)(48*(Math.sin(radiano)));
                
                pX = this.getX() - pX;
                pY = this.getY() - pY;
                
                this.getWorld().addObject(new RastroBlue(), pX, pY);
            }
        }
        else if(getBlocked()==120){
            setBlocked();
            getWorld().removeObjects(getWorld().getObjects(RastroBlue.class));
        }
        else{
            setBlocked();
        }
    }
}
