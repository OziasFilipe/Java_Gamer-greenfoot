import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class RastroBlue extends Rastro{
    private GreenfootImage rastro = getImage();
    
    public RastroBlue(){
        rastro.scale(15,15);
        setImage(rastro);
    }
    
    public void act(){
        dead();
    }
}
