import greenfoot.*;

public class Play extends Button{
    private int timing=0;
    private boolean apagado=false;
    
    public void act(){
        if(Greenfoot.mouseClicked(this) && !this.apagado){
            som();
            ((Menu)getWorld()).stopmusic();
            Greenfoot.setWorld(new Game());
        }
        
        if(this.timing>0){
            this.timing-=5;
            getImage().setTransparency(255-this.timing);
            move(5);
        }
        else if(this.timing<0){
            this.timing+=5;
            getImage().setTransparency(0-this.timing);
            move(-5);
        }
    }
    
    public void voltar(){
        this.timing=255;
        this.apagado=false;
    }
    
    public void sair(){
        this.timing=-255;
        this.apagado=true;
    }
}
