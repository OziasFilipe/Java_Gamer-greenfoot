import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Rastro extends Actor{
    private int dies = 0;
    
    public void dead(){
        if(this.dies == 180){
            getWorld().removeObject(this);
        }
        this.dies++;
    }
}
