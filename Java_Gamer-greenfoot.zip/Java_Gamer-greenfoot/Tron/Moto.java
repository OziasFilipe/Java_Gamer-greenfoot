import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Moto extends Actor{
    private int velocidade=3;
    private int morte=0;
    private int raio=0;
    private int fasttime=120;
    private int slowtime=240;
    private int blocked=0;
    private static boolean fim=false;
    
    public void setCor(){
        GreenfootImage image = getImage();
        image.scale(60, 35);
        setImage(image);
        this.fim=false;
    }
    
    public void setVelo(int v){
        this.velocidade=v;
    }
    
    public void setMorte(){
        this.morte++;
    }
    
    public void setBlocked(){
        this.blocked--;
    }
    
    public boolean getFim(){
        return this.fim;
    }
    
    public int getBlocked(){
        return this.blocked;
    }
    
    public int getVelocidade(){
        return this.velocidade;
    }
    
    public int getMorte(){
        return this.morte;
    }
    
    public void flash(){
        if(this.raio==3){
            double radiano = Math.toRadians(this.getRotation());
            int pX = (int)(120*(Math.cos(radiano)));
            int pY = (int)(120*(Math.sin(radiano)));
            
            pX += this.getX();
            pY += this.getY();
            
            ((Game)getWorld()).flashGif(this.getX(), this.getY());
            this.setLocation(pX,pY);
            ((Game)getWorld()).flashGif(this.getX(), this.getY());
            
            GreenfootSound flashes = new GreenfootSound("flash.mp3");
            flashes.play();
            
            this.raio = 0;
            ((Game)getWorld()).flashing(this);
        }
    }
    
    public void boost(){
        if(this.fasttime<120){
            this.fasttime++;
        }
        else if(this.fasttime==120){
            setVelo(3);
            this.fasttime++;
        }
        
        if(this.slowtime<240){
            this.slowtime++;
        }
        else if(this.slowtime==240){
            setVelo(3);
            this.slowtime++;
        }
    }
    
    public void boom(){
        ((Game)getWorld()).boom(this.getX(), this.getY());
        this.fim=true;
    }
    
    public void tocar(){
        if(isTouching(Raio.class) && this.raio<3){
            GreenfootSound getRaio = new GreenfootSound("raio.mp3");
            getRaio.play();
            this.raio++;
            ((Game)getWorld()).flashing(this);
            getWorld().removeObject(getOneIntersectingObject(Raio.class));
        }
        if(isTouching(Blocker.class)){
            GreenfootSound getBlocker = new GreenfootSound("barreira.mp3");
            getBlocker.setVolume(50);
            getBlocker.play();
            for(Moto motoca : getWorld().getObjects(Moto.class)){
                if(motoca!=this){
                    motoca.blocked=120;
                }
            }
            getWorld().removeObject(getOneIntersectingObject(Blocker.class));
        }
        if(isTouching(Gas.class)){
            GreenfootSound getGas = new GreenfootSound("gasosa.mp3");
            getGas.play();
            this.fasttime = 0;
            setVelo(6);
            getWorld().removeObject(getOneIntersectingObject(Gas.class));
        }
        if(isTouching(Spike.class)){
            GreenfootSound getSpike = new GreenfootSound("slow.mp3");
            getSpike.play();
            for(Moto devagar : getWorld().getObjects(Moto.class)){
                if(devagar!=this){
                    devagar.slowtime = 0;
                    devagar.setVelo(1);
                }
            }
            getWorld().removeObject(getOneIntersectingObject(Spike.class));
        }
        
        if(isTouching(Moto.class)){
            boom();
            getWorld().removeObjects(getWorld().getObjects(Moto.class));
        }
        else if((isTouching(Wall.class)) || (isTouching(Rastro.class))){
            setMorte();
            boom();
            getWorld().removeObject(this);
        }
    }
}
