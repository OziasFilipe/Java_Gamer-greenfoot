import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Stars extends Actor{
    public Stars(){
        turn(90);
    }
    public void up(){
        move(1);
    }
    
    public void down(){
        move(-1);
    }
}
