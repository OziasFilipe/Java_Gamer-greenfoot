import greenfoot.*;

public class Text extends Actor{
}