import greenfoot.*;

public class Menu extends World{
    private GreenfootSound musica = new GreenfootSound("xenogenesis.mp3");
    
    private int timing=0;
    private int howzin=0;
    
    private Stars stars = new Stars();
    private Play play = new Play();
    private HowTo howto = new HowTo();
    private Voltar voltar = new Voltar();
    private TextHow texthow = new TextHow();
    
    public Menu(){
        super(1280, 720, 1);
        
        addObject(stars,640,260);
        addObject(play, 340, 360);
        addObject(howto, 940, 360);
        
        musica.setVolume(20);
        musica.playLoop();
        
        voltar.getImage().setTransparency(0);
        texthow.getImage().setTransparency(0);
    }
    
    public void act(){
        moveStars();
    }
    
    public void stopmusic(){
        musica.stop();
    }
    
    public void openHow(){
        this.howzin=1;
        addObject(voltar, 340, 360);
        addObject(texthow, 940, 360);
        
        play.sair();
        howto.sair();
        voltar.open();
        texthow.open();
    }
    
    public void closeHow(){
        this.howzin=0;
        
        play.voltar();
        howto.voltar();
        voltar.close();
        texthow.close();
    }
    
    public void moveStars(){
        timing++;
        if(this.timing%5==0){
            if((this.timing/1000)%2==0){
                stars.up();
            }
            else{
                stars.down();
            }
        }
    }
}
