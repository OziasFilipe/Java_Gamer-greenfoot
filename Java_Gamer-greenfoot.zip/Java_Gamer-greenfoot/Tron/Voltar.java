import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Voltar extends Button{
    private int timing=0;
    private boolean moving=true;
    
    public void act(){
        if(Greenfoot.mouseClicked(this) && !this.moving){
            som();
            ((Menu)getWorld()).closeHow();
        }
        
        if(this.timing>0){
            this.timing-=5;
            getImage().setTransparency(255-this.timing);
            if(this.timing==0){
                this.moving=false;
            }
        }
        else if(this.timing<0){
            this.timing+=5;
            getImage().setTransparency(0-this.timing);
            if(this.timing==0){
                getWorld().removeObject(this);
            }
        }
    }
    
    public void open(){
        this.timing=255;
        this.moving=true;
    }
    
    public void close(){
        this.timing=-255;
        this.moving=true;
    }
}