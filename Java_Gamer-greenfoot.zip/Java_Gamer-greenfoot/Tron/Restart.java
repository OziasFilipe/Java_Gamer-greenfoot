import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Restart extends Button{
    public void act(){
        if(Greenfoot.mouseClicked(this)){
            som();
            Greenfoot.setWorld(new Game());
        }
    }
}
